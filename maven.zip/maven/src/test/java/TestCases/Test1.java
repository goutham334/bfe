package TestCases;


import org.testng.annotations.Test;

import PageObjects.Commonobjects;



public class Test1 extends BaseClass{
	
	Commonobjects PO = new Commonobjects();

	@Test
	public void test1() {
		try {
		launchBrowser();	
		
			Thread.sleep(5000);
			
			safeClick(PO.registrationBtn, "registrationBtn");
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
}
