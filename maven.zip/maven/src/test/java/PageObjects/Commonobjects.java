package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;



public class Commonobjects  {
	
	public Commonobjects(){
		//super(driver);
	}

	@FindBy(how=How.LINK_TEXT, using="Registration")
	public static WebElement registrationBtn;


}


